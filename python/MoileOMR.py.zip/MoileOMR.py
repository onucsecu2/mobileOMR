import cv2

import numpy as np
image = cv2.imread('/home/onu/Desktop/Untitled Folder/91.jpg')
template = cv2.imread('/home/onu/Desktop/Untitled Folder/raw.jpeg',0)
w, h = template.shape[::-1]
# image = np.zeros((512,512,3), np.uint8)


gray = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
blurred = cv2.GaussianBlur(gray, (13, 13), 0)
edged = cv2.Canny(blurred, 75, 200)

circles = cv2.HoughCircles(blurred,cv2.HOUGH_GRADIENT,1,30,
                            param1=70,param2=45,minRadius=15,maxRadius=50)

circles = np.uint16(np.around(circles))
for i in circles[0,:]:
    # draw the outer circle
    cv2.circle(image,(i[0],i[1]),i[2],(0,255,0),2)
    # draw the center of the circle
    cv2.circle(image,(i[0],i[1]),2,(0,0,255),3)


cv2.namedWindow("output", cv2.WINDOW_NORMAL)
# imS = cv2.resize(image, (960, 540))
cv2.imshow('output',image)
cv2.imwrite('result.png', image)
k=cv2.waitKey(0)
if(k==27):
    exit(0)
cv2.destroyAllWindows()